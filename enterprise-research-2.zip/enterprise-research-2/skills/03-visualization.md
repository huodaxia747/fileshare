# 子技能 03：可视化引擎 · 规范

---

## 图表类型速查

| 需求 | 推荐格式 | 渲染方式 | 可编辑 |
|------|----------|----------|--------|
| 业务流程快速预览 | Mermaid flowchart | 内联 | 否 |
| 系统时序/交互 | Mermaid sequenceDiagram | 内联 | 否 |
| IT架构图（AS-IS/TO-BE） | Mermaid graph TD | 内联 | 否 |
| 实施Roadmap | Mermaid gantt | 内联 | 否 |
| 可编辑专业流程图 | Draw.io XML | 下载 | 完全可编辑 |
| 客户真实流程制度→标准泳道图 | Excel→脚本→.drawio 管线（章节C） | 下载 | 完全可编辑 |
| 数据图表/雷达图 | React/Recharts | 内联 | 否 |
| 差距分析/矩阵 | SVG/React | 内联 | 否 |

**默认策略：** 重要图表同时生成Mermaid内联（预览）+ .drawio文件（可编辑下载）

---

## 颜色规范（严格遵守）

### 业务流程泳道色

| 泳道 | 背景色 | 边框色 | 含义 |
|------|--------|--------|------|
| 客户层 | #e8f5e9 | #43a047 | 外部客户 |
| 销售/L2C层 | #e3f2fd | #1e88e5 | 销售流程 |
| 供应链/S2P层 | #fff3e0 | #fb8c00 | 采购供应 |
| 生产/MFG层 | #fce4ec | #e53935 | 制造执行 |
| 财务/R2R层 | #f3e5f5 | #8e24aa | 财务核算 |
| 痛点标注 | #ffcccc | #e53935 | 需要解决的问题 |

### IT架构图色

| 层级 | 背景色 | 含义 |
|------|--------|------|
| YonBIP核心层 | #003087 | 品牌深蓝 |
| iuap平台层 | #1565C0 | 中蓝 |
| 集成/保留系统 | #E8F5E9 | 浅绿（健康存活） |
| 淘汰/下线系统 | #FFCDD2 | 浅红（将下线） |
| 业务场景层 | #F5F5F5 | 浅灰（客户视角） |

---

## Mermaid 模板库

### 模板1：YonBIP六步AS-IS/TO-BE业务流程图

```mermaid
flowchart TD
    subgraph 客户层["👤 客户层"]
        C1([客户需求]) --> C2[下达订单]
    end
    subgraph L2C层["📊 销售层 L2C"]
        S1[线索登记\nL2C-CLM-b01] --> S2{信用审核}
        S2 -->|通过| S3[报价单\nL2C-B2B-b01]
        S2 -->|拒绝| S_rej[通知拒绝]
        S3 --> S4[合同签订\nL2C-B2B-b03]
    end
    subgraph S2P层["🛒 采购层 S2P"]
        P1[请购单] --> P2[采购订单\nS2P-P02-b01]
        P2 --> P3[到货入库\nS2P-P02-b01-01]
    end
    subgraph MFG层["🏭 生产层 MFG/P2M"]
        M1[生产计划\nP2M-P01] --> M2[工序执行]
        M2 --> M3[质检\nQMS-IQC]
        M3 -->|合格| M4[入库]
        M3 -->|不合格| M5[返工]
    end
    subgraph R2R层["💰 财务层 R2R"]
        F1[发货开票] --> F2[应收账款\nR2R-P09-b01]
        F2 --> F3[收款核销]
        F3 --> F4[总账凭证\nR2R-P10-b01-02]
    end
    C2 --> S1
    S4 --> M1
    P3 --> M1
    M4 --> F1

    style 客户层 fill:#e8f5e9,stroke:#43a047
    style L2C层 fill:#e3f2fd,stroke:#1e88e5
    style S2P层 fill:#fff3e0,stroke:#fb8c00
    style MFG层 fill:#fce4ec,stroke:#e53935
    style R2R层 fill:#f3e5f5,stroke:#8e24aa
```

### 模板2：IT架构 AS-IS（旧系统现状）

```mermaid
graph TD
    subgraph ASIS["❌ 当前IT架构（AS-IS）——数据孤岛"]
        U8_1["U8账套A\n上海公司"]
        U8_2["U8账套B\n南京公司"]
        MES_OLD["自研MES\n.net框架\n接口不稳定"]
        EXCEL["手工Excel\n质量/成本"]
        CRM_OLD["独立CRM\n数据未贯通"]
        
        U8_1 -.- |"手工对账"| U8_2
        MES_OLD -.- |"文件同步"| U8_1
        EXCEL -.- |"手工汇总"| U8_1
        CRM_OLD -.- |"断点"| U8_1
    end
    
    style U8_1 fill:#FFCDD2,stroke:#e53935
    style U8_2 fill:#FFCDD2,stroke:#e53935
    style MES_OLD fill:#FFCDD2,stroke:#e53935
    style EXCEL fill:#FFCDD2,stroke:#e53935
    style CRM_OLD fill:#FFCDD2,stroke:#e53935
```

### 模板3：IT架构 TO-BE（目标架构）

```mermaid
graph TD
    subgraph TOBE["✅ 目标IT架构（TO-BE）——数字底座"]
        subgraph Core["YonBIP核心层"]
            FIN["R2R 财务管理\n多组织多账套"]
            SCM["S2P 供应链\n采购/库存"]
            MFG["P2M/MFG 制造\nQMS质量"]
            L2C["L2C 营销销售\nIPS内部交易"]
        end
        subgraph Platform["iuap平台层"]
            API["API集成中台"]
            MDM["主数据MDM"]
            BI_IUAP["数据中台"]
        end
        subgraph Keep["🔄 保留集成系统"]
            BEISEN["北森HCM\n人才管理"]
            FANRUAN["帆软BI\n复杂报表"]
            INVOICE["诺诺发票\n税务合规"]
        end
        subgraph Deprecated["❌ 下线替换"]
            U8_OLD["U8多账套\n替换下线"]
            EXCEL_OLD["手工Excel\n清除"]
        end
    end
    
    Core --> Platform
    Keep --> Platform
    U8_OLD -.->|"数据迁移"| Core
    EXCEL_OLD -.->|"整理导入"| Core
    
    style Core fill:#e3f2fd,stroke:#003087
    style Platform fill:#fff3e0,stroke:#fb8c00
    style Keep fill:#e8f5e9,stroke:#43a047
    style Deprecated fill:#FFCDD2,stroke:#e53935
```

### 模板4：三阶段蜕变甘特图

```mermaid
gantt
    title YonBIP数字化蜕变实施路径
    dateFormat  YYYY-MM
    axisFormat %Y年%m月
    
    section 夯基 Stabilize
    业务调研与蓝图设计     :done, s1, 2025-01, 1M
    核心财务多组织上线      :done, s2, 2025-02, 2M
    S2P采购供应链上线       :active, s3, 2025-03, 2M
    L2C销售合同管理上线     :s4, 2025-04, 2M
    
    section 提效 Optimize
    QMS质量批次追溯         :o1, 2025-07, 3M
    P2M项目/MFG车间执行     :o2, 2025-08, 3M
    供应商协同门户           :o3, 2025-10, 2M
    BI数据看板               :o4, 2025-11, 2M
    
    section 蜕变 Transform
    AI智能预测               :t1, 2026-02, 3M
    客户/供应商门户          :t2, 2026-04, 2M
    平台化生态接入           :t3, 2026-07, 4M
    
    section 里程碑
    夯基验收                 :milestone, m1, 2025-07, 0d
    提效验收                 :milestone, m2, 2026-01, 0d
    蜕变完成                 :milestone, m3, 2026-12, 0d
```

### 模板5：ETO研发制造时序图

```mermaid
sequenceDiagram
    autonumber
    participant 客户
    participant 销售 as 销售(L2C-B2B)
    participant 研发 as 研发(PLM/ECO)
    participant 计划 as 计划(P2M)
    participant 采购 as 采购(S2P)
    participant 生产 as 生产(MFG)
    participant 质检 as 质检(QMS)
    participant 财务 as 财务(R2R)

    客户->>销售: 提出定制需求
    销售->>研发: 需求转设计任务
    研发->>销售: 返回技术方案+初步BOM
    销售->>客户: 提交报价单 L2C-B2B-b01
    客户->>销售: 确认合同+首付款
    销售->>计划: 触发项目立项 P2M-P01
    计划->>研发: 发布详细设计任务
    研发->>计划: 交付设计BOM+图纸（ECO管控）
    计划->>采购: 发起采购申请 S2P-P02-b01
    采购->>计划: 确认到货日期
    计划->>生产: 下达生产工单 MFG-P01
    生产->>质检: 完工报检 QMS-OQC
    质检->>生产: 质检合格
    生产->>客户: 发货安装
    客户->>销售: 签收验收
    销售->>财务: 里程碑收款 R2R-P09-b01
    财务->>客户: 开具发票
```

---

## Draw.io 文件生成规范

### 颜色规范

```
YonBIP深蓝（主色）：#003087
iuap中蓝（平台色）：#1565C0
痛点红（需关注）：#e53935
价值绿（正向结果）：#43a047
警示橙（注意事项）：#fb8c00
淡蓝背景（L2C域）：#e3f2fd
淡橙背景（S2P域）：#fff3e0
淡红背景（MFG域）：#fce4ec
淡紫背景（R2R域）：#f3e5f5
```

### 文件命名规范

```
[客户名]_[图表类型]_[版本]_[日期].drawio

示例：
裕诗集团_业务流程图_v1_20250519.drawio
裕诗集团_IT架构图ASIS_v1_20250519.drawio
裕诗集团_IT架构图TOBE_v1_20250519.drawio
裕诗集团_蜕变蓝图_v1_20250519.drawio
```

### 必含元素

所有Draw.io专业图必须包含：
- 图例（Legend）：颜色说明
- 标题栏：图表名称+日期+版本
- 企业名称水印（角落）

> ⚠️ 生成 .drawio 文件时，**必须**基于「补充章节 B.6」的 XML 骨架与完整泳道模板改造，不要从空白文件起手。

---

## 补充章节（融合自旧版 references/ · v2.0 未覆盖 · 深度可视化场景按需调用）
### 1.5 差距分析雷达图（用React/Recharts）

适用于：当前状态vs目标状态的多维度差距可视化

生成时使用 React + Recharts RadarChart，嵌入对话中直接渲染。

```javascript
// 示例数据结构
const data = [
  { dimension: '报价效率', current: 3, target: 9 },
  { dimension: '计划准确', current: 4, target: 8 },
  { dimension: '成本可视', current: 2, target: 8 },
  { dimension: '质量追溯', current: 3, target: 9 },
  { dimension: '财务协同', current: 5, target: 9 },
  { dimension: '决策数据', current: 2, target: 8 },
];
```

---

## 四、常用图表快速生成指令

使用以下指令快速触发对应图表生成：

| 指令 | 生成内容 |
|------|----------|
| `画[行业]业务流程图` | 泳道式Mermaid流程图 + .drawio文件 |
| `画YonBIP架构图` | 四层架构SVG + .drawio文件 |
| `画蜕变路径` | 三阶段甘特图Mermaid + .drawio时间轴 |
| `画差距分析图` | 雷达图React组件（内联） |
| `画时序图[场景]` | Mermaid sequenceDiagram |
| `画痛点矩阵` | 四象限SVG（严重度×频率） |
| `生成完整可视化包` | 上述所有图表打包为.zip |

---

## 补充章节 B（回填自 v1.0 master · 业务流程视角模板 + Draw.io 可执行 XML）

> 调用规则同「补充章节」：**轻量场景**（快速情报卡、单图、简报）仅用上文内核；
> **深度场景**（正式交付包、客户汇报、需交付可编辑 .drawio 文件）额外调用本节。
> 本节与上文 Mermaid 模板库互补：上文模板侧重 **IT 规划视角**（AS-IS/TO-BE 架构），
> 本节侧重 **业务流程视角**（L2C / P2M / S2P / MFG / FIN 五层泳道）。

### B.1 可视化类型选择矩阵（含可编辑性）

| 用户需求 | 推荐格式 | 渲染方式 | 可编辑性 |
|----------|----------|----------|----------|
| 快速预览流程 | Mermaid | 内联渲染 | 不可编辑 |
| 可编辑流程图 | Draw.io (.drawio) | 下载后导入 | 完全可编辑 |
| 专业架构图 | SVG + Draw.io | 内联+下载 | Draw.io可编辑 |
| 数据图表 | Mermaid pie/gantt | 内联渲染 | 不可编辑 |
| 企业级方案图 | Draw.io | 下载后导入 | 完全可编辑 |
| 时序/交互图 | Mermaid sequence | 内联渲染 | 不可编辑 |

**默认策略：** 先输出 Mermaid 内联预览，同时生成对应 .drawio 文件供下载。

### B.2 业务流程图（L2C / P2M / S2P / MFG / FIN 五层泳道）

适用于：端到端业务流程可视化，暴露跨部门协同断点

```mermaid
flowchart TD
    subgraph 客户层
        A([客户需求]) --> B[提交订单]
    end
    subgraph 销售层_L2C
        C[线索登记] --> D{信用审核}
        D -->|通过| E[生成报价单]
        D -->|拒绝| F[通知客户]
        E --> G[客户确认]
    end
    subgraph 计划层_SCM
        H[生成生产计划] --> I{物料齐套?}
        I -->|是| J[下达生产工单]
        I -->|否| K[触发采购申请]
        K --> L[S2P采购流程]
        L --> I
    end
    subgraph 制造层_MFG
        M[车间接单] --> N[工序执行]
        N --> O{质检}
        O -->|合格| P[入库]
        O -->|不合格| Q[返工/报废]
    end
    subgraph 财务层_FIN
        R[发货确认] --> S[开票应收]
        S --> T[收款核销]
    end

    B --> C
    G --> H
    J --> M
    P --> R

    style A fill:#e3f2fd
    style 客户层 fill:#e8f5e9,stroke:#43a047
    style 销售层_L2C fill:#e3f2fd,stroke:#1e88e5
    style 计划层_SCM fill:#fff3e0,stroke:#fb8c00
    style 制造层_MFG fill:#fce4ec,stroke:#e53935
    style 财务层_FIN fill:#f3e5f5,stroke:#8e24aa
```

### B.3 ETO 项目型制造时序图

适用于：按单设计（ETO）的完整交付流程，跨 8 个角色

```mermaid
sequenceDiagram
    autonumber
    participant 客户
    participant 销售 as 销售(L2C)
    participant 设计 as 设计(PLM)
    participant 计划 as 计划(P2M)
    participant 采购 as 采购(S2P)
    participant 生产 as 生产(MFG)
    participant 质检 as 质检(QMS)
    participant 财务 as 财务(FIN)

    客户->>销售: 提出定制需求
    销售->>设计: 需求转设计任务
    设计->>销售: 返回技术方案+初步BOM
    销售->>客户: 提交报价单
    客户->>销售: 确认合同+首付款
    销售->>计划: 触发项目立项(P2M-P01)
    计划->>设计: 发布详细设计任务
    设计->>计划: 交付设计BOM+图纸
    计划->>采购: 发起采购申请(S2P-P01)
    采购->>计划: 确认采购到货日期
    计划->>生产: 下达生产工单(MFG-P01)
    生产->>质检: 完工报检
    质检->>生产: 质检合格
    生产->>客户: 发货安装
    客户->>销售: 签收验收
    销售->>财务: 触发里程碑收款(FIN-AR)
    财务->>客户: 开具发票
```

### B.4 YonBIP 四层解决方案架构图

适用于：YonBIP 解决方案架构展示（业务场景 → 应用 → 平台 → 部署）

```mermaid
flowchart TB
    subgraph 业务场景层["🏭 业务场景层（客户业务）"]
        direction LR
        B1[全渠道销售]
        B2[按单设计/制造]
        B3[供应链协同]
        B4[项目交付]
        B5[财务结算]
    end

    subgraph 应用层["📦 YonBIP 应用层"]
        direction LR
        A1[L2C<br/>线索到现金]
        A2[P2M<br/>项目到制造]
        A3[S2P<br/>寻源到付款]
        A4[MFG<br/>制造执行]
        A5[FIN<br/>财务管理]
        A6[QMS<br/>质量管理]
        A7[HCM<br/>人力资源]
    end

    subgraph 平台层["⚙️ iuap 开放平台"]
        direction LR
        P1[数据中台]
        P2[集成平台]
        P3[低代码开发]
        P4[AI引擎]
    end

    subgraph 基础层["☁️ 部署层"]
        direction LR
        I1[公有云YonSaaS]
        I2[私有化部署]
        I3[混合云]
    end

    业务场景层 --> 应用层
    应用层 --> 平台层
    平台层 --> 基础层

    B1 -.-> A1
    B2 -.-> A2
    B3 -.-> A3
    B4 -.-> A4
    B5 -.-> A5

    style 业务场景层 fill:#e8f5e9,stroke:#43a047
    style 应用层 fill:#e3f2fd,stroke:#1e88e5
    style 平台层 fill:#fff3e0,stroke:#fb8c00
    style 基础层 fill:#f3e5f5,stroke:#8e24aa
```

### B.5 蜕变路径甘特图（含里程碑）

适用于：三阶段实施 Roadmap 与验收节点

```mermaid
gantt
    title YonBIP 蜕变实施路径
    dateFormat  YYYY-MM
    axisFormat %Y年%m月

    section 夯基阶段 Stabilize
    业务调研与蓝图设计     :done, s1, 2025-01, 1M
    L2C核心流程上线        :done, s2, 2025-02, 2M
    P2M项目管理上线        :active, s3, 2025-03, 2M
    FIN财务贯通            :s4, 2025-04, 2M

    section 提效阶段 Optimize
    MRP/APS高级排程        :o1, 2025-06, 3M
    多组织协同平台         :o2, 2025-07, 2M
    供应商协同门户(S2P)    :o3, 2025-08, 2M
    BI数据看板             :o4, 2025-10, 2M

    section 蜕变阶段 Transform
    AI智能预测             :t1, 2026-01, 3M
    行业云接入             :t2, 2026-03, 2M
    生态平台搭建           :t3, 2026-06, 4M

    section 里程碑
    夯基验收               :milestone, m1, 2025-06, 0d
    提效验收               :milestone, m2, 2025-12, 0d
    蜕变完成               :milestone, m3, 2026-12, 0d
```

### B.6 Draw.io 可执行 XML 模板

#### B.6.1 文件结构骨架

所有 .drawio 文件的最小骨架，图表内容从 `id=2` 开始：

```xml
<?xml version="1.0" encoding="UTF-8"?>
<mxGraphModel
  dx="1422" dy="762"
  grid="1" gridSize="10"
  guides="1" tooltips="1"
  connect="1" arrows="1"
  fold="1" page="1"
  pageScale="1" pageWidth="1169" pageHeight="827"
  math="0" shadow="0">
  <root>
    <mxCell id="0"/>
    <mxCell id="1" parent="0"/>
    <!-- 图表内容从id=2开始 -->
  </root>
</mxGraphModel>
```

#### B.6.2 颜色规范（企业调研主题 · 8 色）

```
主色调（YonBIP蓝）：#003087  用于：主流程、主标题
辅色调（信息蓝）：#1e88e5   用于：系统模块背景
强调色（红）：#e53935        用于：痛点、异常、风险
成功色（绿）：#43a047        用于：完成、价值、优势
警告色（橙）：#fb8c00        用于：注意事项、待处理
中性色（灰）：#757575        用于：辅助信息
背景色（浅蓝）：#e3f2fd     用于：客户层背景
背景色（浅绿）：#e8f5e9     用于：价值层背景
```

#### B.6.3 业务流程图完整模板（可直接落盘为 .drawio）

五层泳道（客户 / 销售 / 计划 / 生产 / 财务），含标题栏、节点、连线、图例四要素：

```xml
<?xml version="1.0" encoding="UTF-8"?>
<mxGraphModel dx="1422" dy="762" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="1654" pageHeight="1169" math="0" shadow="0">
  <root>
    <mxCell id="0" />
    <mxCell id="1" parent="0" />

    <!-- 标题 -->
    <mxCell id="title" value="[行业名称] 核心业务流程图"
      style="text;html=1;strokeColor=none;fillColor=none;align=center;verticalAlign=middle;whiteSpace=wrap;rounded=0;fontSize=18;fontStyle=1;fontColor=#003087;"
      vertex="1" parent="1">
      <mxGeometry x="300" y="20" width="600" height="40" as="geometry" />
    </mxCell>

    <!-- 泳道容器 -->
    <mxCell id="pool" value=""
      style="shape=pool;startSize=0;horizontal=1;childLayout=stackLayout;horizontalStack=0;resizeParent=1;resizeParentMax=0;collapsible=0;marginBottom=0;"
      vertex="1" parent="1">
      <mxGeometry x="40" y="80" width="1200" height="600" as="geometry" />
    </mxCell>

    <!-- 泳道1：客户层 -->
    <mxCell id="lane1" value="客户"
      style="swimlane;startSize=30;horizontal=0;fillColor=#e8f5e9;strokeColor=#43a047;fontStyle=1;fontSize=12;"
      vertex="1" parent="pool">
      <mxGeometry x="0" y="0" width="1200" height="120" as="geometry" />
    </mxCell>

    <!-- 泳道2：销售层 -->
    <mxCell id="lane2" value="销售 (L2C)"
      style="swimlane;startSize=30;horizontal=0;fillColor=#e3f2fd;strokeColor=#1e88e5;fontStyle=1;fontSize=12;"
      vertex="1" parent="pool">
      <mxGeometry x="0" y="120" width="1200" height="120" as="geometry" />
    </mxCell>

    <!-- 泳道3：计划层 -->
    <mxCell id="lane3" value="计划 (P2M/SCM)"
      style="swimlane;startSize=30;horizontal=0;fillColor=#fff3e0;strokeColor=#fb8c00;fontStyle=1;fontSize=12;"
      vertex="1" parent="pool">
      <mxGeometry x="0" y="240" width="1200" height="120" as="geometry" />
    </mxCell>

    <!-- 泳道4：生产层 -->
    <mxCell id="lane4" value="生产 (MFG)"
      style="swimlane;startSize=30;horizontal=0;fillColor=#fce4ec;strokeColor=#e53935;fontStyle=1;fontSize=12;"
      vertex="1" parent="pool">
      <mxGeometry x="0" y="360" width="1200" height="120" as="geometry" />
    </mxCell>

    <!-- 泳道5：财务层 -->
    <mxCell id="lane5" value="财务 (FIN)"
      style="swimlane;startSize=30;horizontal=0;fillColor=#f3e5f5;strokeColor=#8e24aa;fontStyle=1;fontSize=12;"
      vertex="1" parent="pool">
      <mxGeometry x="0" y="480" width="1200" height="120" as="geometry" />
    </mxCell>

    <!-- 节点示例：客户提需求 -->
    <mxCell id="n1" value="提出需求"
      style="ellipse;whiteSpace=wrap;html=1;fillColor=#e8f5e9;strokeColor=#43a047;fontSize=11;"
      vertex="1" parent="lane1">
      <mxGeometry x="60" y="40" width="100" height="40" as="geometry" />
    </mxCell>

    <!-- 节点示例：线索登记 -->
    <mxCell id="n2" value="线索登记&#xa;L2C-b01"
      style="rounded=1;whiteSpace=wrap;html=1;fillColor=#e3f2fd;strokeColor=#1e88e5;fontSize=11;"
      vertex="1" parent="lane2">
      <mxGeometry x="220" y="40" width="120" height="40" as="geometry" />
    </mxCell>

    <!-- 连线示例 -->
    <mxCell id="e1" edge="1" source="n1" target="n2" parent="pool">
      <mxStyle style="edgeStyle=orthogonalEdgeStyle;html=1;exitX=1;exitY=0.5;entryX=0;entryY=0.5;" />
      <mxGeometry relative="1" as="geometry" />
    </mxCell>

    <!-- 图例 -->
    <mxCell id="legend_title" value="图例"
      style="text;html=1;fontStyle=1;fontSize=12;fillColor=#f5f5f5;strokeColor=#666666;"
      vertex="1" parent="1">
      <mxGeometry x="40" y="720" width="60" height="30" as="geometry" />
    </mxCell>
    <mxCell id="legend1" value="系统节点"
      style="rounded=1;fillColor=#e3f2fd;strokeColor=#1e88e5;"
      vertex="1" parent="1">
      <mxGeometry x="110" y="720" width="100" height="30" as="geometry" />
    </mxCell>
    <mxCell id="legend2" value="决策节点"
      style="rhombus;fillColor=#fff3e0;strokeColor=#fb8c00;"
      vertex="1" parent="1">
      <mxGeometry x="230" y="715" width="100" height="40" as="geometry" />
    </mxCell>
    <mxCell id="legend3" value="起止节点"
      style="ellipse;fillColor=#e8f5e9;strokeColor=#43a047;"
      vertex="1" parent="1">
      <mxGeometry x="350" y="720" width="100" height="30" as="geometry" />
    </mxCell>
    <mxCell id="legend4" value="痛点"
      style="rounded=1;fillColor=#ffcccc;strokeColor=#e53935;"
      vertex="1" parent="1">
      <mxGeometry x="470" y="720" width="100" height="30" as="geometry" />
    </mxCell>

  </root>
</mxGraphModel>
```

#### B.6.4 架构图 / 蜕变蓝图 Draw.io 模板要点

**YonBIP 解决方案架构图**——分层架构，颜色按层区分：

- 业务层（顶）：浅绿 `#e8f5e9`
- 应用层：浅蓝 `#e3f2fd`
- 平台层：浅橙 `#fff3e0`
- 基础层（底）：浅紫 `#f3e5f5`

**蜕变蓝图（时间轴式）**——横向时间轴，三个阶段用不同颜色区分：

- 夯基 Stabilize：蓝色系 `#1e88e5`
- 提效 Optimize：橙色系 `#fb8c00`
- 蜕变 Transform：紫色系 `#8e24aa`

### B.7 质量检查与命名规范

#### 图表生成前检查清单

- [ ] 确认图表类型（流程 / 时序 / 架构 / 甘特 / 雷达）
- [ ] 确认行业和场景（定制家居 / 工程机械 / ...）
- [ ] 确认 YonBIP 流程域（L2C / P2M / S2P / MFG / FIN）
- [ ] 确认输出格式（Mermaid 内联 / Draw.io 文件 / 两者都要）

#### Mermaid 图表质量规范

- 节点标签：中文 + 英文编码（如 `报价管理\nL2C-b01`）
- 关键痛点节点：用红色边框标注（`style: stroke:#e53935`）
- 自动化流程：实线箭头；人工操作：虚线箭头
- 每张图节点数控制在 15 个以内，超出拆分多张

#### Draw.io 文件命名规范（归档版）

```
[客户名/行业名]_[图表类型]_[日期].drawio

示例：
定制家居_业务流程图_20250504.drawio
工程机械_YonBIP架构图_20250504.drawio
ABC公司_蜕变蓝图_20250504.drawio
```

---

## 补充章节 C（融合自 x-to-drawio-swimlane · 工程化泳道图生成管线）

> 上面 B.2/B.6 提供 Mermaid 与手写 XML 模板，适合调研汇报中的示意图。
> 本章节提供**可执行管线**：输入（图片/文档/Excel）→ 业务语言模板 Excel → 脚本渲染 → 标准 .drawio。
> 适合：客户真实流程制度文档的标准化泳道图、需要用户确认提取结果后再出图的场景。

### C.1 管线总览（单一收敛路径，不跳步）

| 场景 | 输入 | 路径 |
|---|---|---|
| 1 | 手绘流程照片 / 截图 / 扫描件 | AI 视觉识图 → 提取泳道/节点/连线 → 填模板 Excel → 渲染 |
| 2 | Word 流程制度（纯文字或表格）、宽行 Excel 流程清单 | 按源类型解析 → 填模板 Excel → 渲染 |
| 3 | 已是「流程信息 + 业务流程」格式的模板 Excel | 直接渲染 |

**铁律：Excel 是抽取与渲染之间的契约，永远不跳过。** 场景 1/2 必须先按 `references/swimlane-extraction-guide.md` 抽取并填 Excel，**展示给用户确认后**再跑渲染脚本——抽取错误在 Excel 阶段修正远比在成品图上便宜。

### C.2 业务语言模板 Excel（首选，`assets/业务语言流程泳道图模板.xlsx`）

两个工作表：

- `流程信息`：一行一图。列：`流程编号`、`流程名称`、`图标题`、`备注`。
- `业务流程`：一行一步骤。业务用户**只需填**：

| 字段 | 说明 |
|---|---|
| `步骤编号` | 简单 id 如 S01/S02，仅用于表达"下一步去哪" |
| `流程阶段` | 可选业务阶段，如 需求提出/合同签署/付款归档 |
| `办理角色` | 部门/岗位/角色；脚本自动把去重后的角色转成泳道 |
| `业务动作` | 业务语言动作，如 `审批采购结果` |
| `动作类型` | `办理`/`审批`/`判断`/`文档`/`归档`/`子流程`/`开始`/`结束` |
| `正常下一步` | 通过后的下一步 id；并行分支逗号分隔如 `S07,S08` |
| `否/退回去向` | 驳回/失败/缺料/返工时的去向 id |
| `异常去向` | 可选特殊异常分支 |
| `并行组` | 可选，标记同属一个并行评审组的步骤 |
| `是否结束` | 末步骤填 `是` |
| `备注` | 给建模者的备注，默认不渲染 |

禁止让业务用户填坐标、连线 id、泳道 id、手工路径点——那是高级模板的事。

### C.3 高级模板（`assets/excel-swimlane-template.xlsx`，仅建模者精确控图时用）

四个工作表：`流程信息`（含方向/起止节点）、`泳道`（泳道ID/名称/顺序/宽度/角色类型）、`节点`（节点ID/泳道ID/文本/类型/顺序/XYWH）、`连线`（起点/终点/标签/路由类型/手工路径点）。

节点类型 `task`/`document`/`decision`/`start`/`end`/`subprocess`；连线 `route_type=auto`（正交自动路由）或 `manual`（`manual_points` 分号分隔 `x,y` 点，避免标签旁出现小折弯）。完整字段规范见 `references/swimlane-template-spec.md`。

### C.4 渲染脚本

```bash
python scripts/excel_to_drawio_swimlane.py \
  --input /path/to/流程.xlsx \
  --process-id 11.3.3 \
  --output /path/to/输出.drawio
```

- `--process-name`：无编号时按名称选择流程。
- `--style blue-white`：默认蓝白风格。
- `--template-mode business|standard|legacy|auto`：默认 `auto`，自动识别业务语言/高级/旧版格式。
- 生成后校验：`xmllint --noout 输出.drawio`，并核对所有抽取步骤均已出图为节点。
- ⚠️ **路径必须用 Windows 风格**（`E:/dir/file.drawio` 或 `E:\\dir\\file.drawio`），不要传 Git Bash 的 `/e/dir/...` 风格——Windows Python 不识别，会把 `/e/...` 当作当前盘根下的 `\e\...` 目录并静默新建目录树写入。

### C.5 蓝白风格规范（与 B 章节手绘模板风格统一）

- 白底 + 细蓝泳道边框；标题行/泳道头：白底蓝粗体字。
- 流程节点：实心蓝 `#2F70C9` 白字直角矩形；文档节点用 `document` 波浪底形状；判断/审批用菱形。
- 箭头：细蓝 `#4C64FF`，classic 箭头，正交直段。
- 禁止：圆角卡片、渐变、阴影、浅色填充、虚线回退线、装饰性批注、泳道/表格边框错位。

### C.6 布局规则

- 默认纵向泳道：泳道为列，流程自上而下。
- `title.width == sum(lane.width)` 且 `title.x == first_lane.x`；所有泳道 y/高度一致。
- 同行节点中心 Y 对齐；同行/同泳道相邻节点用直线箭头。
- 回退/「否」路径用手工路径点走一个干净直角；**跨泳道向上回退**走最左泳道内侧通道；**跨泳道向下「否」分支**从判断节点左角直连目标顶部，不得绕左通道。任何连线不得画出泳道边框。
- 标签过长手动插 `<br/>`，不得把字号缩到 14 以下；`是/否/通过/退回` 标签放直线段附近，白底标签。
- 视觉问题直接改 `.drawio` 修几何，不回退到抽取步骤重跑。

### C.7 旧版宽行 Excel 抽取（如 `L3流程文档清单（带流程解析）`）

- 用含流程编号/名称/文件名的列定位目标行，后续编号列即步骤。
- 角色名从末尾括号提取，如 `审批招聘方案(招聘审批人)`。
- 步骤引用其他流程名且无角色文字 → 放入 `前序流程` 泳道。
- 动词推断：`审批/审核/评审/确认` → 判断节点；`制定/编制/输出/归档/发布` → 文档节点。
- 无显式分支时用顺序箭头；仅在语义要求审批通过/驳回或用户要求时才加 `是/否` 分支。
- 图像/Word/表格的逐字段抽取规则见 `references/swimlane-extraction-guide.md`（§1 图片、§2 Word 纯文字、§3 表格、§4 旧版宽行、§7 跨泳道回退布局模板）。
