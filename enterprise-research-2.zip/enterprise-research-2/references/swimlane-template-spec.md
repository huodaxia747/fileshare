# Excel Swimlane Template Specification

Use this reference when designing Excel data for swimlane diagrams. Prefer the business-language template for normal users.

> If the source input is an image or a Word/Excel document rather than a ready-made template, see `references/extraction-guide.md` for how to extract process data into the sheets below.

## Recommended Sheet: 业务流程

| Column | Required | Meaning |
|---|---:|---|
| 步骤编号 | yes | Simple step id such as `S01`. Used by next-step fields. |
| 流程阶段 | no | Business phase, e.g. `需求提出`, `合同签署`. |
| 办理角色 | yes | Department/person/role. Unique values become swimlanes. |
| 业务动作 | yes | Plain business-language action. |
| 动作类型 | yes | `办理`, `审批`, `判断`, `文档`, `归档`, `子流程`, `开始`, `结束`. |
| 正常下一步 | no | Next step id; comma-separated ids mean parallel branches. |
| 否/退回去向 | no | Rejection/rework destination step id. |
| 异常去向 | no | Special exception branch destination. |
| 并行组 | no | Same group label for steps that belong to the same parallel review group. |
| 是否结束 | no | Fill `是` on the final step. |
| 备注 | no | Notes for the modeler. |

Business users should only need this sheet plus `流程信息`.

## Advanced Template

Use these sheets only when precise diagram geometry is required.

## Sheet: 流程信息

| Column | Required | Meaning |
|---|---:|---|
| 流程编号 | yes | Stable process code, e.g. `11.3.3`. |
| 流程名称 | yes | Business process name. |
| 图标题 | no | Diagram title. Defaults to `{流程编号} {流程名称} 业务流程泳道图`. |
| 方向 | no | Default `vertical`. |
| 开始节点ID | no | Optional start node. |
| 结束节点ID | no | Optional end node. |
| 备注 | no | Source notes, usually not rendered unless requested. |

## Sheet: 泳道

| Column | Required | Meaning |
|---|---:|---|
| 泳道ID | yes | Stable id used by Nodes. |
| 泳道名称 | yes | Header text shown in diagram. |
| 顺序 | yes | Left-to-right lane order. |
| 宽度 | no | Column width in draw.io units. Defaults to 360-480 depending on complexity. |
| 角色类型 | no | Optional grouping such as `前序`, `执行`, `审批`, `外部`. |

## Sheet: 节点

| Column | Required | Meaning |
|---|---:|---|
| 节点ID | yes | Stable id used by Edges. |
| 流程编号 | yes | Process id. |
| 泳道ID | yes | Lane id. |
| 节点文本 | yes | Node text. Use concise text; line breaks are allowed. |
| 节点类型 | yes | `task`, `document`, `decision`, `start`, `end`, `subprocess`. |
| 顺序 | no | Top-to-bottom order when x/y are blank. |
| X坐标 | no | Absolute x. Leave blank for auto layout. |
| Y坐标 | no | Absolute y. Leave blank for auto layout. |
| 宽度 | no | Node width. |
| 高度 | no | Node height. |
| 说明 | no | Extra detail not usually rendered. |

## Sheet: 连线

| Column | Required | Meaning |
|---|---:|---|
| 连线ID | yes | Stable edge id. |
| 流程编号 | yes | Process id. |
| 起点节点ID | no | Source node. Can be blank when using explicit 起点坐标. |
| 终点节点ID | no | Target node. Can be blank when using explicit 终点坐标. |
| 连线标签 | no | Edge label such as `是`, `否`, `通过`, `退回`. |
| 路由类型 | no | `auto` or `manual`. |
| 手工路径点 | no | Semicolon-separated points, e.g. `600,620;600,510`. |
| 起点坐标 | no | Explicit source endpoint, e.g. `1000,620`. |
| 终点坐标 | no | Explicit target endpoint, e.g. `600,481`. |

## Complex Process Patterns

- Multi-branch approval: create one `decision` node and multiple Edges with labels.
- Rollback/rework: add an Edge from decision/task back to the earlier node. Use `route_type=manual` and explicit points.
- Parallel work: create multiple outgoing Edges from the same node to different lanes; rejoin with a later task/decision.
- External organization: add a lane with `role_type=外部`; keep it rightmost unless the source process says otherwise.
- Subprocess: use `node_type=subprocess`; if details are available, create a separate Process row for the child flow.
