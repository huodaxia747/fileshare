#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
import sys
from dataclasses import dataclass
from datetime import datetime
from html import escape
from pathlib import Path
from typing import Iterable
from xml.dom import minidom
from xml.etree.ElementTree import Element, SubElement, tostring

try:
    import openpyxl
except Exception as exc:  # pragma: no cover
    print(f"openpyxl is required to read Excel files: {exc}", file=sys.stderr)
    raise


BLUE = "#2F70C9"
LINE_BLUE = "#4C64FF"

SHEET_ALIASES = {
    "Process": ("Process", "流程信息"),
    "Lanes": ("Lanes", "泳道"),
    "Nodes": ("Nodes", "节点"),
    "Edges": ("Edges", "连线"),
}

HEADER_ALIASES = {
    "序号": "business_order",
    "步骤编号": "step_id",
    "流程阶段": "phase",
    "办理角色": "business_role",
    "办理部门/角色": "business_role",
    "业务动作": "business_action",
    "动作类型": "business_type",
    "正常下一步": "next_step",
    "通过去向": "next_step",
    "否/退回去向": "reject_step",
    "退回去向": "reject_step",
    "异常去向": "exception_step",
    "分支说明": "branch_note",
    "并行组": "parallel_group",
    "是否结束": "is_end",
    "流程编号": "process_id",
    "流程名称": "process_name",
    "图标题": "diagram_title",
    "方向": "orientation",
    "开始节点ID": "start_node_id",
    "结束节点ID": "end_node_id",
    "备注": "notes",
    "泳道ID": "lane_id",
    "泳道名称": "lane_name",
    "顺序": "order",
    "宽度": "width",
    "角色类型": "role_type",
    "节点ID": "node_id",
    "节点文本": "label",
    "节点类型": "node_type",
    "X坐标": "x",
    "Y坐标": "y",
    "高度": "height",
    "说明": "description",
    "连线ID": "edge_id",
    "起点节点ID": "from_node_id",
    "终点节点ID": "to_node_id",
    "连线标签": "label",
    "路由类型": "route_type",
    "手工路径点": "manual_points",
    "起点坐标": "source_point",
    "终点坐标": "target_point",
}

BUSINESS_TYPE_MAP = {
    "办理": "task",
    "任务": "task",
    "审批": "decision",
    "审核": "decision",
    "判断": "decision",
    "评审": "decision",
    "文档": "document",
    "输出": "document",
    "归档": "document",
    "子流程": "subprocess",
    "开始": "start",
    "结束": "end",
}


@dataclass
class Lane:
    lane_id: str
    name: str
    order: int
    width: int = 420
    x: int = 0


@dataclass
class Node:
    node_id: str
    process_id: str
    lane_id: str
    label: str
    node_type: str = "task"
    order: int = 0
    x: int | None = None
    y: int | None = None
    width: int | None = None
    height: int | None = None


@dataclass
class Edge:
    edge_id: str
    process_id: str
    source: str | None
    target: str | None
    label: str = ""
    route_type: str = "auto"
    manual_points: list[tuple[int, int]] | None = None
    source_point: tuple[int, int] | None = None
    target_point: tuple[int, int] | None = None


def norm(value) -> str:
    return "" if value is None else str(value).strip()


def canonical_header(header: str) -> str:
    return HEADER_ALIASES.get(header, header)


def get_sheet(wb, canonical_name: str):
    for name in SHEET_ALIASES[canonical_name]:
        if name in wb.sheetnames:
            return wb[name]
    raise KeyError(canonical_name)


def has_standard_sheets(wb) -> bool:
    return all(any(name in wb.sheetnames for name in aliases) for aliases in SHEET_ALIASES.values())


def has_business_sheet(wb) -> bool:
    return "业务流程" in wb.sheetnames


def sheet_rows(ws) -> list[dict[str, str]]:
    headers = [canonical_header(norm(c.value)) for c in ws[1]]
    rows = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        item = {headers[i]: norm(v) for i, v in enumerate(row) if i < len(headers) and headers[i]}
        if any(item.values()):
            rows.append(item)
    return rows


def parse_point(text: str) -> tuple[int, int] | None:
    if not text:
        return None
    m = re.match(r"\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*$", text)
    if not m:
        return None
    return int(float(m.group(1))), int(float(m.group(2)))


def parse_points(text: str) -> list[tuple[int, int]]:
    return [p for p in (parse_point(part) for part in text.split(";")) if p]


def classify_node(label: str) -> str:
    if any(k in label for k in ("审批", "审核", "评审", "确认")):
        return "decision"
    if any(k in label for k in ("制定", "编制", "输出", "归档", "发布")):
        return "document"
    return "task"


def business_node_type(action_type: str, action: str, is_end: str = "") -> str:
    text = action_type.strip()
    if is_end in ("是", "Y", "YES", "yes", "1", "true", "True"):
        return "end"
    if text in BUSINESS_TYPE_MAP:
        return BUSINESS_TYPE_MAP[text]
    return classify_node(action)


def split_targets(text: str) -> list[str]:
    if not text:
        return []
    parts = re.split(r"[;,；，、/]+", text)
    return [p.strip() for p in parts if p.strip()]


def safe_id(raw: str, prefix: str) -> str:
    value = re.sub(r"\W+", "_", raw.strip(), flags=re.UNICODE).strip("_")
    return f"{prefix}_{value}" if value else prefix


def load_business(wb, process_id: str, process_name: str | None):
    info = {}
    if "流程信息" in wb.sheetnames:
        rows = sheet_rows(wb["流程信息"])
        if rows:
            info = rows[0]
    pid = process_id or info.get("process_id") or "PROCESS"
    pname = process_name or info.get("process_name") or "业务流程"
    title = info.get("diagram_title") or f"{pid} {pname} 业务流程泳道图"

    rows = sheet_rows(wb["业务流程"])
    if process_id:
        rows = [row for row in rows if not row.get("process_id") or row.get("process_id") == process_id]
    if not rows:
        raise ValueError("No business process rows were found in 业务流程 sheet.")

    roles: list[str] = []
    for row in rows:
        role = row.get("business_role") or "流程参与人"
        if role not in roles:
            roles.append(role)
    lanes = [Lane(safe_id(role, "lane"), role, idx + 1, 380) for idx, role in enumerate(roles)]
    lane_by_role = {lane.name: lane.lane_id for lane in lanes}

    # Parallel group rows share a visual row. Otherwise row position follows business order.
    group_y: dict[str, int] = {}
    next_row = 0
    nodes: list[Node] = []
    step_to_node: dict[str, str] = {}
    for idx, row in enumerate(rows, start=1):
        step = row.get("step_id") or row.get("business_order") or str(idx)
        role = row.get("business_role") or "流程参与人"
        action = row.get("business_action") or f"步骤{step}"
        phase = row.get("phase")
        label = f"{phase}\n{action}" if phase else action
        group = row.get("parallel_group")
        if group:
            if group not in group_y:
                next_row += 1
                group_y[group] = next_row
            row_num = group_y[group]
        else:
            next_row += 1
            row_num = next_row
        node_id = safe_id(step, "n")
        step_to_node[step] = node_id
        nodes.append(
            Node(
                node_id=node_id,
                process_id=pid,
                lane_id=lane_by_role[role],
                label=label,
                node_type=business_node_type(row.get("business_type", ""), action, row.get("is_end", "")),
                order=row_num,
            )
        )

    edges: list[Edge] = []
    edge_count = 1
    for idx, row in enumerate(rows, start=1):
        step = row.get("step_id") or row.get("business_order") or str(idx)
        source = step_to_node.get(step)
        if not source:
            continue

        def add_targets(target_text: str, label: str):
            nonlocal edge_count
            for target_step in split_targets(target_text):
                target = step_to_node.get(target_step)
                if target:
                    edges.append(Edge(f"e{edge_count}", pid, source, target, label))
                    edge_count += 1

        add_targets(row.get("next_step", ""), "是" if row.get("reject_step") and row.get("business_type") in ("审批", "审核", "判断", "评审") else "")
        add_targets(row.get("reject_step", ""), "否")
        add_targets(row.get("exception_step", ""), row.get("branch_note") or "异常")

    if not edges:
        for i in range(1, len(nodes)):
            edges.append(Edge(f"e{i}", pid, nodes[i - 1].node_id, nodes[i].node_id))
    return pid, title, lanes, nodes, edges


def role_from_step(step: str) -> tuple[str, str]:
    m = re.match(r"^(.*?)[（(]([^（）()]+)[）)]$", step.strip())
    if not m:
        return step.strip(), ""
    return m.group(1).strip(), m.group(2).strip()


def load_standard(wb, process_id: str, process_name: str | None):
    process_rows = sheet_rows(get_sheet(wb, "Process"))
    selected = None
    for row in process_rows:
        if process_id and row.get("process_id") == process_id:
            selected = row
            break
        if process_name and process_name in row.get("process_name", ""):
            selected = row
            break
    if not selected:
        raise ValueError("Requested process was not found in Process sheet.")

    pid = selected["process_id"]
    lanes = [
        Lane(
            lane_id=row["lane_id"],
            name=row["lane_name"],
            order=int(float(row.get("order") or 0)),
            width=int(float(row.get("width") or 420)),
        )
        for row in sheet_rows(get_sheet(wb, "Lanes"))
        if row.get("lane_id")
    ]
    nodes = [
        Node(
            node_id=row["node_id"],
            process_id=row.get("process_id") or pid,
            lane_id=row["lane_id"],
            label=row["label"],
            node_type=row.get("node_type") or "task",
            order=int(float(row.get("order") or 0)),
            x=int(float(row["x"])) if row.get("x") else None,
            y=int(float(row["y"])) if row.get("y") else None,
            width=int(float(row["width"])) if row.get("width") else None,
            height=int(float(row["height"])) if row.get("height") else None,
        )
        for row in sheet_rows(get_sheet(wb, "Nodes"))
        if (row.get("process_id") or pid) == pid and row.get("node_id")
    ]
    edges = [
        Edge(
            edge_id=row["edge_id"],
            process_id=row.get("process_id") or pid,
            source=row.get("from_node_id") or None,
            target=row.get("to_node_id") or None,
            label=row.get("label") or "",
            route_type=row.get("route_type") or "auto",
            manual_points=parse_points(row.get("manual_points") or ""),
            source_point=parse_point(row.get("source_point") or ""),
            target_point=parse_point(row.get("target_point") or ""),
        )
        for row in sheet_rows(get_sheet(wb, "Edges"))
        if (row.get("process_id") or pid) == pid and row.get("edge_id")
    ]
    title = selected.get("diagram_title") or f"{pid} {selected.get('process_name', '')} 业务流程泳道图"
    return pid, title, lanes, nodes, edges


def load_legacy(wb, process_id: str, process_name: str | None):
    ws = wb.active
    headers = [norm(c.value) for c in ws[1]]
    target = None
    for row in ws.iter_rows(min_row=2, values_only=True):
        values = [norm(v) for v in row]
        if process_id and process_id in values:
            target = values
            break
        if process_name and any(process_name in v for v in values):
            target = values
            break
    if not target:
        raise ValueError("Requested process was not found in legacy sheet.")

    pid = target[2] if len(target) > 2 else process_id
    pname = target[3] if len(target) > 3 else process_name or ""
    steps = [v for v in target[6:] if v]
    parsed = [role_from_step(step) for step in steps]
    roles = []
    for label, role in parsed:
        if not role and label == pname:
            role = "前序流程"
        if role and role not in roles:
            roles.append(role)
    if not roles:
        roles = ["流程参与人"]

    lanes = [Lane("lane_pre", "前序流程", 1, 320)]
    for i, role in enumerate([r for r in roles if r != "前序流程"], start=2):
        lanes.append(Lane(f"lane_{i}", role, i, 480))
    role_to_lane = {"前序流程": "lane_pre"}
    for lane in lanes[1:]:
        role_to_lane[lane.name] = lane.lane_id

    nodes = []
    for i, (label, role) in enumerate(parsed, start=1):
        lane_id = role_to_lane.get(role or ("前序流程" if i == 1 else lanes[min(1, len(lanes) - 1)].name), lanes[0].lane_id)
        nodes.append(Node(f"n{i}", pid, lane_id, label, classify_node(label), i))
    edges = [Edge(f"e{i}", pid, f"n{i}", f"n{i+1}") for i in range(1, len(nodes))]
    return pid, f"{pid} {pname}_1 业务流程泳道图", lanes, nodes, edges


def mx_cell(root: Element, **attrs) -> Element:
    return SubElement(root, "mxCell", {k: str(v) for k, v in attrs.items() if v not in (None, "")})


def geometry(parent: Element, x=None, y=None, w=None, h=None, relative=None):
    attrs = {"as": "geometry"}
    if x is not None:
        attrs["x"] = str(x)
    if y is not None:
        attrs["y"] = str(y)
    if w is not None:
        attrs["width"] = str(w)
    if h is not None:
        attrs["height"] = str(h)
    if relative is not None:
        attrs["relative"] = str(relative)
    return SubElement(parent, "mxGeometry", attrs)


def node_style(node_type: str) -> str:
    base = f"whiteSpace=wrap;html=1;fillColor={BLUE};strokeColor=#3F5DFF;strokeWidth=1;fontColor=#FFFFFF;fontSize=17;align=center;verticalAlign=middle;spacing=8;"
    if node_type == "decision":
        return "rhombus;" + base
    if node_type == "document":
        return "shape=document;boundedLbl=1;" + base
    return "rounded=0;" + base


def add_vertex(root: Element, id_: str, value: str, x: int, y: int, w: int, h: int, style: str):
    c = mx_cell(root, id=id_, value=escape(value).replace("\n", "<br/>"), style=style, vertex="1", parent="1")
    geometry(c, x, y, w, h)


def add_edge(root: Element, edge: Edge):
    style = f"edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;endArrow=classic;endFill=1;strokeColor={LINE_BLUE};strokeWidth=1.4;fontColor=#333333;fontSize=14;labelBackgroundColor=#FFFFFF;"
    attrs = {"id": edge.edge_id, "value": edge.label, "style": style, "edge": "1", "parent": "1"}
    if edge.source:
        attrs["source"] = edge.source
    if edge.target:
        attrs["target"] = edge.target
    c = mx_cell(root, **attrs)
    g = geometry(c, relative=1)
    if edge.source_point:
        SubElement(g, "mxPoint", {"x": str(edge.source_point[0]), "y": str(edge.source_point[1]), "as": "sourcePoint"})
    if edge.target_point:
        SubElement(g, "mxPoint", {"x": str(edge.target_point[0]), "y": str(edge.target_point[1]), "as": "targetPoint"})
    if edge.manual_points:
        arr = SubElement(g, "Array", {"as": "points"})
        for x, y in edge.manual_points:
            SubElement(arr, "mxPoint", {"x": str(x), "y": str(y)})


def layout(lanes: list[Lane], nodes: list[Node]):
    x = 30
    for lane in sorted(lanes, key=lambda l: l.order):
        lane.x = x
        x += lane.width
    lane_map = {lane.lane_id: lane for lane in lanes}
    per_lane_counts = {}
    for node in sorted(nodes, key=lambda n: n.order):
        lane = lane_map[node.lane_id]
        per_lane_counts[node.lane_id] = per_lane_counts.get(node.lane_id, 0) + 1
        if node.width is None:
            node.width = 260 if node.node_type in ("document", "decision") else 220
        if node.height is None:
            node.height = 112 if node.node_type == "decision" else 78
        if node.x is None:
            node.x = lane.x + (lane.width - node.width) // 2
        if node.y is None:
            node.y = 150 + (node.order - 1) * 115


def render_drawio(title: str, lanes: list[Lane], nodes: list[Node], edges: list[Edge], output: Path):
    layout(lanes, nodes)
    lane_total = sum(l.width for l in sorted(lanes, key=lambda l: l.order))
    lane_top, header_h = 68, 36
    page_h = max([n.y + (n.height or 78) for n in nodes] + [900]) + 90

    mxfile = Element("mxfile", {"host": "app.diagrams.net", "modified": datetime.now().isoformat(timespec="seconds"), "agent": "Codex", "type": "device"})
    diagram = SubElement(mxfile, "diagram", {"id": "excel-swimlane", "name": title[:80]})
    model = SubElement(diagram, "mxGraphModel", {"dx": "1280", "dy": "900", "grid": "1", "gridSize": "10", "guides": "1", "tooltips": "1", "connect": "1", "arrows": "1", "fold": "1", "page": "1", "pageScale": "1", "pageWidth": str(lane_total + 60), "pageHeight": str(page_h), "math": "0", "shadow": "0"})
    root = SubElement(model, "root")
    mx_cell(root, id="0")
    mx_cell(root, id="1", parent="0")

    title_style = "rounded=0;whiteSpace=wrap;html=1;fillColor=#FFFFFF;strokeColor=#4C64FF;strokeWidth=1;fontColor=#2F70C9;fontSize=22;fontStyle=1;align=center;verticalAlign=middle;"
    lane_style = "rounded=0;whiteSpace=wrap;html=1;fillColor=#FFFFFF;strokeColor=#4C64FF;strokeWidth=1;"
    header_style = "rounded=0;whiteSpace=wrap;html=1;fillColor=#FFFFFF;strokeColor=#4C64FF;fontColor=#2F70C9;fontSize=21;fontStyle=1;align=center;verticalAlign=middle;"
    add_vertex(root, "title", title, 30, 30, lane_total, 38, title_style)
    for lane in sorted(lanes, key=lambda l: l.order):
        add_vertex(root, lane.lane_id, "", lane.x, lane_top, lane.width, page_h - lane_top - 40, lane_style)
        add_vertex(root, f"{lane.lane_id}_h", lane.name, lane.x, lane_top, lane.width, header_h, header_style)
    for node in nodes:
        add_vertex(root, node.node_id, node.label, node.x or 0, node.y or 0, node.width or 220, node.height or 78, node_style(node.node_type))
    for edge in edges:
        add_edge(root, edge)

    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(minidom.parseString(tostring(mxfile, encoding="utf-8")).toprettyxml(indent="  ", encoding="utf-8"))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--process-id", default="")
    parser.add_argument("--process-name", default="")
    parser.add_argument("--template-mode", choices=["auto", "business", "standard", "legacy"], default="auto")
    parser.add_argument("--style", default="blue-white")
    args = parser.parse_args()

    wb = openpyxl.load_workbook(args.input, data_only=True)
    is_standard = has_standard_sheets(wb)
    if args.template_mode == "business" or (args.template_mode == "auto" and has_business_sheet(wb)):
        _, title, lanes, nodes, edges = load_business(wb, args.process_id, args.process_name or None)
    elif args.template_mode == "standard" or (args.template_mode == "auto" and is_standard):
        _, title, lanes, nodes, edges = load_standard(wb, args.process_id, args.process_name or None)
    else:
        _, title, lanes, nodes, edges = load_legacy(wb, args.process_id, args.process_name or None)
    render_drawio(title, lanes, nodes, edges, Path(args.output))
    print(args.output)


if __name__ == "__main__":
    main()
