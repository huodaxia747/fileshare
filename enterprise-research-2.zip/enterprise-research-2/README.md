# 企业调研 · YonBIP售前全能助手 v2.2

## 文件结构
```
enterprise-research/
├── SKILL.md                        主技能入口（必读）
├── skills/
│   ├── 01-industry-insight.md      行业洞察引擎（六步+麦肯锡+黑话库+8题快诊）
│   ├── 02-yonbip-architecture.md   YonBIP架构引擎（完整流程编码+IT规划）
│   ├── 03-visualization.md         可视化引擎（Mermaid+Draw.io XML模板）
│   ├── 04-document-generation.md   文档生成引擎（Word/PPT/Excel样式代码）
│   └── 05-data-acquisition.md      数据获取引擎（含JD分析报告模板）
├── evals/
│   └── evals.json                  评测用例
└── examples/
    └── usage-examples.md           完整使用示例（5个场景）
```

## v2.0核心升级（相比v1.0）
- YonBIP流程编码：完整5.0清单，S2P/L2C/R2R全域精确编码
- IT规划深度：旗舰版六步IT规划（AS-IS→TO-BE）
- 旧系统处置：每个旧系统明确"替换/保留/升级"策略
- 词汇提取：四类专有词汇+ASR热词包+易错词对照
- 分步执行：每步暂停确认，用户可控节奏

## v2.1升级（v1.0 master 资产回填合并）
v2.1 将旧版 master（enterprise-research-master，四引擎）中未被 v2.0 继承的全部高价值资产
回填进各引擎的「补充章节 B」，实现单一技能、双版本内容全覆盖：
- 可视化：补齐 Draw.io 可执行 XML（骨架+五层泳道完整模板）、4 套业务流程视角 Mermaid 模板、质量检查清单
- 文档生成：补齐 Word/PPT/Excel 样式代码常量（COLORS/FONTS/SIZES）、行业调研版章节结构、Excel 五表定义、打包脚本
- 行业洞察：补齐行业大类分类树、成熟度8题快诊问卷、黑话库行级补齐（10行）
- 数据获取：补齐 JD 分析报告输出模板
- 环境适配：移除云端沙箱路径（/mnt/...），文档生成走本机 Office 技能路由

## v2.2升级（融合 x-to-drawio-swimlane 泳道图管线）
将独立的 x-to-drawio-swimlane 技能整体融合进可视化引擎，新增「补充章节 C」工程化泳道图生成管线：
- 管线：输入（流程照片/Word 制度/宽行 Excel）→ 业务语言模板 Excel（用户确认）→ 脚本渲染 → 标准蓝白 .drawio
- 随技能分发的可执行资产：`scripts/excel_to_drawio_swimlane.py`、`assets/业务语言流程泳道图模板.xlsx`、`assets/excel-swimlane-template.xlsx`、`references/swimlane-extraction-guide.md`、`references/swimlane-template-spec.md`
- 分工：真实流程制度标准化泳道图走章节 C 管线；调研汇报示意图用内核/补充章节 B 的 Mermaid 与 XML 模板

## 核心约束
1. 流程编码必须来自《YonBIP领先实践业务场景流程清单5.0》
2. 每个旧系统必须给出明确处置策略
3. 六步IT规划必须分步暂停确认
4. 禁止绝对化承诺话术

## 依赖说明
文档生成（Word/PPT/Excel）通过本机 Office 技能路由执行：
- Word → tencent-docx
- PPT → tencent-pptx
- Excel → tencent-docs-sheet-generation
- 入口 → tencent-docs-routing

版本：v2.2 | 日期：2026-09-05
